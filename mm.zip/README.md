# zby

![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=CyberXBD&repo=zby)

PHP CC CHECKER TELEGRAM BOT
Free cc checker bot https://t.me/NXDD_Bot

JOIN FOR MORE BOT https://t.me/NXDDUpdates

## Use
Edit this file ```funct/functions.php```

Update Your $botToken

Then Set Webhook ```youhost.com/webhook.php```

> This Bot Is Free And Open Source You can edit it as you want.

Don’t Forget To Join Our Channel
